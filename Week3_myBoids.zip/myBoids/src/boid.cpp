#include "boid.h"

void Boid::setup(float x, float y, ofColor color, Mouser &mouse) {
	location.set(x, y);
	this->color = color;
	this->mouse = &mouse;
}

void Boid::update() {
	//Calculate desired acceleration using seeking behaviour.
	acceleration = seek(mouse->getLocation());

	//Apply the acceleration to the Boid's velocity.
	velocity += acceleration; 	
	
	// Limit Boid to a maximum speed.
	velocity.limit(MAX_SPEED); 
	
	location += velocity; 	
}

ofVec2f Boid::seek(ofVec2f targetLocation) {
	// Delta between target location and current location
	ofVec2f desireLine = targetLocation - location;

	// The length of the distance to cover.
	float distanceToCover = desireLine.length();
	
	// Starting from a max, scale down the boid's speed, as we approach target.
	float approachSpeed = MAX_SPEED;
	if (distanceToCover < SLOW_APPROACH_RADIUS) {
		approachSpeed *= distanceToCover / SLOW_APPROACH_RADIUS;
	}

	// Boid desires to move at full speed towards the target location.
	ofVec2f steeringUnitVector = desireLine.normalize();
	ofVec2f fullSpeedTowardsTarget = steeringUnitVector * approachSpeed;

	// What's the difference between full speed towards target and boid's current velocity?
	ofVec2f velocityCorrectedSteeringForce = fullSpeedTowardsTarget - velocity;

	// Limt steering force to a maximum.
	velocityCorrectedSteeringForce.limit(MAX_FORCE);

	// accelerate according to the steering force.
	return velocityCorrectedSteeringForce;
}

void Boid::draw() {

	float mouthLength = DRAW_RADIUS * 1 + 1 * velocity.length();

	ofPushMatrix();
	ofTranslate(location.x, location.y);
	ofRotateZDeg(headingInDegrees());                

	ofSetLineWidth(DRAW_STROKE);                     // Set stroke witdh for lines
	ofSetColor(ofColor::orange);                      // Stroke is orange
	ofDrawCircle(0, 0, DRAW_RADIUS + DRAW_STROKE);   // Draw the "body" stroke
	ofSetColor(color);                               // Fill is this->color
	ofDrawCircle(0, 0, DRAW_RADIUS);                 // Draw the "body" fill
	ofSetColor(ofColor::orange);                      // Stroke is orange
	ofDrawLine(0, 0, mouthLength, 0);                 // Draw the "mouth" stroke
	
	ofPopMatrix();                                   // Pop the saved global coordinates
}

/* Public Getter - Boid's Location */

ofVec2f Boid::getLocation() {
	return location;
}

/* Private Helper - Boid's Heading in Degrees */

float Boid::headingInDegrees() {
	// The angle between the xAxis and the boid's velocity is:	
	ofVec2f xAxis(1, 0);
	return xAxis.angle(velocity);
}


