#include "Mouser.h"

/* Set Mouser location to the location of the mouse pointer. */

void Mouser::update() {
	location.x = ofGetMouseX();
	location.y = ofGetMouseY();
}

void Mouser::draw(ofVec2f otherLocation)
{
	// How far is the other?
	float distanceToOther = location.distance(otherLocation);

	// Draw pseudo-stroke in orangeRed
	ofSetColor(ofColor::orangeRed);
	ofDrawCircle(location.x, location.y, DRAW_RADIUS + DRAW_STROKE);

	// The fill changes if other location is in our 2x radius hit zone.
	if (distanceToOther <= DRAW_RADIUS * 2) {
		ofSetColor(TOUCHING_COLOR);  
	}
	else {
		ofSetColor(DEFAULT_COLOR);  
	}

	// Draw circle with selected fill color.
	ofDrawCircle(location.x, location.y, DRAW_RADIUS);  
}

/* Public Getter - Mouse Location */

ofVec2f Mouser::getLocation() {
	return location;
}
