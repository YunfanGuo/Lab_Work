#pragma once

#include "ofMain.h"

class Mouser
{
	/* Play with these constants to tweak how mouse pointer is drawn. */
	const float DRAW_RADIUS = 25;
	const float DRAW_STROKE = 5;
	const ofColor DEFAULT_COLOR = ofColor::orange;
	const ofColor TOUCHING_COLOR = ofColor::white;

	/* Private Properties */
	ofVec2f location;

public:
	void update();
	void draw();
	void draw(ofVec2f otherLocation);
	ofVec2f getLocation();
};

