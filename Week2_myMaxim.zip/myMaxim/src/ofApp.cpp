#include "ofApp.h"
#include "ofxMaxim.h"

//--------------------------------------------------------------
void ofApp::setup(){
    env.setAttack(2000);
    env.setDecay(1);
    env.setSustain(1);
    env.setRelease(3000);
    
    ofSetFrameRate(60);
    
    sampleRate = 44100;
    bufferSize = 512;
    
    ofBackground(0);
    ofSetupScreen();
    
    fft.setup(1024, 512, 256);
    oct.setup(44100, 1024, 10);
    
    frequency = 220;
    modulationSpeed = 2;
    ofSoundStreamSetup(2,0,this,sampleRate,bufferSize,4);
    
    startTime = ofGetElapsedTimeMillis();
    endTime = 1000;

}

//--------------------------------------------------------------
void ofApp::update(){
    currentTime = ofGetElapsedTimeMillis() - startTime;
    
    if(currentTime >= endTime){
        env.trigger = 1;
        startTime = ofGetElapsedTimeMillis();
    }else{
        env.trigger = 0;
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0, 0, 0);
    for(int i = 0; i < oct.nAverages; i++){
        ofColor colour;
        colour.setHsb((int) ofMap(i, 0, oct.nAverages, 0, 255), 255, 255);
        ofSetColor(colour);
        
        float size = 1 + oct.averages[i] / 10;
        int x = (int) ((ofGetWidth()/2) * i / oct.nAverages) + ofGetWidth()/4;
        
        ofDrawCircle(x, ofGetHeight()/2, size);
    }


}

//--------------------------------------------------------------
void ofApp::audioOut(float * output, int bufferSize, int nChannels){
    for (unsigned i = 0; i < bufferSize; i++){
        
        currentSample = env.adsr((osc.sinewave(frequency + frequencyMod.sinewave(1)) * modulator.sinewave(modulationSpeed))*0.3, env.trigger);
        
        if(fft.process(currentSample)){
            oct.calculate(fft.magnitudes);
        }
        
        mix.stereo(currentSample, outputs, panner.sinewave(1)+1/2);
        
        output[i * nChannels] = outputs[0];
        output[i * nChannels + 1] = outputs[1];
    }

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    frequency = (double) ofMap(x, 0, ofGetWidth(), 0, 1000);
    modulationSpeed = (double) ofMap(x, 0, ofGetWidth(), 0, 50);
    env.setAttack(floor(ofMap(x, 0, ofGetWidth(), 500, 4000)));

}


